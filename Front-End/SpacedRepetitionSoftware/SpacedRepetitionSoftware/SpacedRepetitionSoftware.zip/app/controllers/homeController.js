app.controller('homeController', function ($scope, $http, $location) {


    $scope.message = 'Everyone come and see how good I look!';


});
